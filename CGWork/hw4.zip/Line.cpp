//#include "Line.h"
//
//Line::Line(const Vertex &v1, const Vertex &v2) :
//	_v1(v1),
//	_v2(v2),
//	_m(0.0),
//	_valid_slope(false)
//{
//	
//}