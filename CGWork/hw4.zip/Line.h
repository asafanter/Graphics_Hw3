//#pragma once
//
//#include "afxwin.h"
//#include "Types.h"
//
//class Line
//{
//public:
//	Line(const Vertex &v1, const Vertex &v2);
//	
//public: //members
//	Vertex _v1;
//	Vertex _v2;
//	Pixel _p1;
//	Pixel _p2;
//	double _m;
//	bool _valid_slope;
//};
//
